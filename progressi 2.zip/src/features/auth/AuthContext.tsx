import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User } from '../../services/types';
import { api } from '../../services/api';

interface AuthContextType {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    hasStudio: boolean | null; // null = checking
    signIn: (email: string, password?: string) => Promise<void>;
    signUp: (email: string, password: string) => Promise<boolean>;
    signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [hasStudio, setHasStudio] = useState<boolean | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        checkUser();
    }, []);

    function normalizeRole(role: string): any {
        const r = role.toLowerCase();
        if (r === 'owner') return 'owner';
        if (r === 'studio_admin') return 'STUDIO_ADMIN';
        if (r === 'manager') return 'MANAGER';
        if (r === 'artist') return 'ARTIST';
        if (r === 'student') return 'STUDENT';
        return 'STUDENT';
    }

    async function checkUser() {
        console.log('AuthContext: Checking user session...');
        try {
            const currentUser = await api.auth.getCurrentUser();
            console.log('AuthContext: User found:', currentUser ? currentUser.id : 'null');

            if (currentUser) {
                // Normalize role
                currentUser.role = normalizeRole(currentUser.role);
                setUser(currentUser);

                const membership = await api.settings.checkMembership(currentUser.id);
                setHasStudio(membership);
            } else {
                setUser(null);
                setHasStudio(false);
            }
        } catch (error) {
            console.error('Failed to restore session:', error);
        } finally {
            console.log('AuthContext: Set loading false');
            setIsLoading(false);
        }
    }

    async function signUp(email: string, password: string): Promise<boolean> {
        setIsLoading(true);
        try {
            const session = await api.auth.signUp(email, password);
            if (session && session.user) {
                session.user.role = normalizeRole(session.user.role);
                setUser(session.user);
                return true; // Auto-login successful
            }
            return false; // Confirmation required
        } finally {
            setIsLoading(false);
        }
    }

    async function signIn(email: string, password?: string) {
        setIsLoading(true);
        try {
            const session = await api.auth.signIn(email, password || 'password-ignored-in-mock');
            if (session.user) {
                session.user.role = normalizeRole(session.user.role);
                setUser(session.user);
                const membership = await api.settings.checkMembership(session.user.id);
                setHasStudio(membership);
            } else {
                setUser(null);
            }
        } finally {
            setIsLoading(false);
        }
    }

    async function signOut() {
        setIsLoading(true);
        try {
            await api.auth.signOut();
            setUser(null);
            setHasStudio(false);
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, hasStudio, signIn, signUp, signOut }}>
            {children}
        </AuthContext.Provider>
    );
}


export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
