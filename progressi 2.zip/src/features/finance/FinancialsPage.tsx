import React, { useState, useEffect } from 'react';
import {
    DollarSign,
    TrendingUp,
    TrendingDown,
    Filter,
    Download
} from 'lucide-react';
import { api } from '../../services/api';
import type { Transaction, FinancialStats, ArtistContract } from '../../services/types';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { it } from 'date-fns/locale';
import clsx from 'clsx';
import { useAuth } from '../auth/AuthContext';
import { useLayoutStore } from '../../stores/layoutStore';

export const FinancialsPage: React.FC = () => {
    const { user } = useAuth();
    const { isPrivacyMode } = useLayoutStore();
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [stats, setStats] = useState<FinancialStats | null>(null);
    const [loading, setLoading] = useState(true);
    const [contract, setContract] = useState<ArtistContract | null>(null);

    // Default to current month
    const [dateRange, setDateRange] = useState({
        start: startOfMonth(new Date()),
        end: endOfMonth(new Date())
    });
    const [isFilterOpen, setIsFilterOpen] = useState(false);

    useEffect(() => {
        if (user) {
            loadData();
        }
    }, [dateRange, user]);

    const loadData = async () => {
        // ... (existing loadData logic is fine, no changes needed here, just keeping context)
        setLoading(true);
        try {
            if (!user) return;
            const [allTxs, globalStats] = await Promise.all([
                api.financials.listTransactions(dateRange.start, dateRange.end),
                api.financials.getStats(dateRange.start)
            ]);

            if (user.role === 'ARTIST') {
                const artistContract = await api.artists.getContract(user.id);
                setContract(artistContract);
                const commissionRate = artistContract?.commission_rate || 50;
                const artistTxs = allTxs.filter(tx => tx.artist_id === user.id);
                setTransactions(artistTxs);
                const income = artistTxs.filter(tx => tx.type === 'INCOME').reduce((acc, tx) => acc + (tx.amount * commissionRate / 100), 0);
                const expenses = artistTxs.filter(tx => tx.type === 'EXPENSE').reduce((acc, tx) => acc + tx.amount, 0);
                setStats({ revenue_month: income, expenses_month: expenses, revenue_today: 0 });
            } else {
                setTransactions(allTxs);
                setStats(globalStats);
            }
        } finally {
            setLoading(false);
        }
    };

    const handleExport = () => {
        if (transactions.length === 0) {
            alert('Nessuna transazione da esportare.');
            return;
        }

        const headers = ["Data", "Categoria", "Descrizione", "Tipo", "Importo", "Quota"];
        const csvContent = [
            headers.join(','),
            ...transactions.map(tx => {
                const amount = user?.role === 'ARTIST' && tx.type === 'INCOME'
                    ? (tx.amount * (contract?.commission_rate || 50) / 100)
                    : tx.amount;

                return [
                    format(new Date(tx.date), 'yyyy-MM-dd'),
                    `"${tx.category}"`,
                    `"${tx.description || ''}"`,
                    tx.type,
                    tx.amount.toFixed(2),
                    amount.toFixed(2)
                ].join(',');
            })
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `financials_${format(dateRange.start, 'yyyyMMdd')}_${format(dateRange.end, 'yyyyMMdd')}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    const formatCurrency = (amount: number) => {
        if (isPrivacyMode) return '••••••';
        return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(amount);
    };

    if (!user) return null;

    return (
        <div className="w-full p-4 md:p-8 space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white">
                        {user.role === 'ARTIST' ? 'Le Tue Finanze' : 'Finanze Studio'}
                    </h1>
                    <p className="text-text-muted">
                        {user.role === 'ARTIST'
                            ? 'Monitora i tuoi guadagni e le commissioni.'
                            : 'Monitora entrate, uscite e commissioni.'}
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => setIsFilterOpen(!isFilterOpen)}
                        className={clsx(
                            "flex items-center gap-2 border hover:bg-white/5 px-4 py-2 rounded-lg font-medium transition-colors",
                            isFilterOpen ? "bg-accent border-accent text-white" : "bg-bg-secondary border-border text-text-primary"
                        )}
                    >
                        <Filter size={18} />
                        <span>Filtra</span>
                    </button>
                    <button
                        onClick={handleExport}
                        className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium transition-colors border border-white/10"
                    >
                        <Download size={18} />
                        <span className="hidden md:inline">Esporta Report</span>
                    </button>
                </div>
            </div>

            {/* Filter Panel */}
            {isFilterOpen && (
                <div className="bg-bg-secondary p-4 rounded-lg border border-border animate-in fade-in slide-in-from-top-2 mb-6">
                    <div className="flex flex-col md:flex-row gap-4 items-end">
                        <div className="w-full md:w-auto">
                            <label className="block text-xs text-text-muted mb-1">Data Inizio</label>
                            <input
                                type="date"
                                value={format(dateRange.start, 'yyyy-MM-dd')}
                                onChange={(e) => {
                                    if (e.target.value) {
                                        setDateRange(prev => ({ ...prev, start: new Date(e.target.value) }));
                                    }
                                }}
                                className="bg-bg-tertiary border border-border text-white text-sm rounded-lg p-2.5 outline-none focus:border-accent w-full"
                            />
                        </div>
                        <div className="w-full md:w-auto">
                            <label className="block text-xs text-text-muted mb-1">Data Fine</label>
                            <input
                                type="date"
                                value={format(dateRange.end, 'yyyy-MM-dd')}
                                onChange={(e) => {
                                    if (e.target.value) {
                                        setDateRange(prev => ({ ...prev, end: new Date(e.target.value) }));
                                    }
                                }}
                                className="bg-bg-tertiary border border-border text-white text-sm rounded-lg p-2.5 outline-none focus:border-accent w-full"
                            />
                        </div>
                        <div className="w-full md:w-auto">
                            <button
                                onClick={() => setDateRange({
                                    start: startOfMonth(new Date()),
                                    end: endOfMonth(new Date())
                                })}
                                className="text-sm text-accent hover:underline px-2 py-2.5"
                            >
                                Mese Corrente
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'I Tuoi Guadagni (Mese)' : 'Entrate Totali (Mese)'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">{stats ? formatCurrency(stats.revenue_month) : '-'}</h3>
                        <div className="p-2 bg-green-500/10 text-green-500 rounded-lg"><TrendingUp size={20} /></div>
                    </div>
                </div>
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'Spese Delegate' : 'Uscite (Mese)'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">{stats ? formatCurrency(stats.expenses_month) : '-'}</h3>
                        <div className="p-2 bg-red-500/10 text-red-500 rounded-lg"><TrendingDown size={20} /></div>
                    </div>
                </div>
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'Netto Stimato' : 'Utile Netto'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">
                            {stats ? formatCurrency(stats.revenue_month - stats.expenses_month) : '-'}
                        </h3>
                        <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg"><DollarSign size={20} /></div>
                    </div>
                </div>
            </div>

            {/* Chart Placeholder (Mock) */}
            <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                <h3 className="text-lg font-bold text-white mb-6">Andamento Entrate</h3>
                <div className="h-64 flex items-end justify-between gap-2 px-2">
                    {[40, 65, 30, 80, 55, 90, 45, 70, 60, 85, 50, 75].map((h, i) => (
                        <div key={i} className="w-full bg-bg-tertiary hover:bg-accent/50 transition-colors rounded-t-sm relative group" style={{ height: `${h}%` }}>
                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                {isPrivacyMode ? '•••' : `€${h * 10}`}
                            </div>
                        </div>
                    ))}
                </div>
                <div className="flex justify-between mt-4 text-xs text-text-muted px-2">
                    {['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'].map(m => (
                        <span key={m}>{m}</span>
                    ))}
                </div>
            </div>

            {/* Desktop Transactions Table */}
            <div className="hidden md:block bg-bg-secondary rounded-lg border border-border overflow-hidden">
                <div className="p-6 border-b border-border">
                    <h3 className="text-lg font-bold text-white">Transazioni Recenti</h3>
                </div>
                <table className="w-full text-left border-collapse">
                    <thead className="bg-bg-tertiary">
                        <tr className="text-sm text-text-muted font-medium border-b border-border">
                            <th className="px-6 py-3">Data</th>
                            <th className="px-6 py-3">Descrizione/Categoria</th>
                            <th className="px-6 py-3">Tipo</th>
                            <th className="px-6 py-3 text-right">
                                {user.role === 'ARTIST' ? 'Tua Quota' : 'Importo'}
                            </th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {loading ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Caricamento transazioni...</td></tr>
                        ) : transactions.length === 0 ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Nessuna transazione trovata.</td></tr>
                        ) : (
                            transactions.map(tx => {
                                const amount = user.role === 'ARTIST' && tx.type === 'INCOME'
                                    ? (tx.amount * (contract?.commission_rate || 50) / 100)
                                    : tx.amount;

                                return (
                                    <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                                        <td className="px-6 py-4 text-sm text-text-secondary">
                                            {format(new Date(tx.date), 'dd MMM yyyy', { locale: it })}
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-white">{tx.category}</div>
                                            {tx.description && <div className="text-xs text-text-muted">{tx.description}</div>}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={clsx(
                                                "text-xs px-2 py-1 rounded font-medium",
                                                tx.type === 'INCOME' ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                                            )}>
                                                {tx.type === 'INCOME' ? 'ENTRATA' : 'USCITA'}
                                            </span>
                                        </td>
                                        <td className={clsx(
                                            "px-6 py-4 text-right font-medium",
                                            tx.type === 'INCOME' ? "text-green-500" : "text-text-primary"
                                        )}>
                                            {tx.type === 'EXPENSE' ? '-' : '+'}{formatCurrency(amount)}
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>

            {/* Mobile Transactions Card View */}
            <div className="md:hidden space-y-4">
                <h3 className="text-lg font-bold text-white px-2">Transazioni Recenti</h3>
                {loading ? (
                    <div className="p-8 text-center text-text-muted">Caricamento...</div>
                ) : transactions.length === 0 ? (
                    <div className="p-8 text-center text-text-muted">Nessuna transazione.</div>
                ) : (
                    transactions.map(tx => {
                        const amount = user.role === 'ARTIST' && tx.type === 'INCOME'
                            ? (tx.amount * (contract?.commission_rate || 50) / 100)
                            : tx.amount;

                        return (
                            <div key={tx.id} className="bg-bg-secondary border border-border rounded-xl p-4 flex flex-col gap-3">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="font-bold text-white">{tx.category}</div>
                                        <div className="text-xs text-text-muted">{format(new Date(tx.date), 'dd MMM yyyy', { locale: it })}</div>
                                    </div>
                                    <span className={clsx(
                                        "text-[10px] px-2 py-0.5 rounded font-medium",
                                        tx.type === 'INCOME' ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                                    )}>
                                        {tx.type === 'INCOME' ? 'ENTRATA' : 'USCITA'}
                                    </span>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div className="text-xs text-text-muted italic truncate max-w-[150px]">{tx.description}</div>
                                    <div className={clsx(
                                        "font-bold",
                                        tx.type === 'INCOME' ? "text-green-500" : "text-white"
                                    )}>
                                        {tx.type === 'EXPENSE' ? '-' : '+'}{formatCurrency(amount)}
                                    </div>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>

        </div >
    );
};
