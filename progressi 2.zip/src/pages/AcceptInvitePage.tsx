import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../services/api';
import { useAuth } from '../features/auth/AuthContext';
import { Mail, Shield, AlertTriangle, Key } from 'lucide-react';

export const AcceptInvitePage: React.FC = () => {
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token');
    const navigate = useNavigate();
    useAuth(); // Keep hook execution if needed for side effects, or remove if not used at all. 
    // Actually useAuth is likely not needed if we use api.auth directly, but maybe it initializes something?
    // The previous code had:  const { signIn, signUp } = useAuth();
    // I switched to api.auth.signIn/signUp.
    // I'll keep useAuth import but remove destructuring or just remove the line if safe.
    // Let's just remove the destructuring.

    const [loading, setLoading] = useState(true);
    const [invitationError, setInvitationError] = useState<string | null>(null); // For token validation errors
    const [authError, setAuthError] = useState<string | null>(null); // For login/signup errors
    const [invitation, setInvitation] = useState<any | null>(null);

    // Auth Form State
    const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const [authLoading, setAuthLoading] = useState(false);

    useEffect(() => {
        validateToken();
    }, [token]);

    const validateToken = async () => {
        if (!token) {
            setInvitationError('Token di invito mancante.');
            setLoading(false);
            return;
        }

        try {
            const invite = await api.settings.getInvitation(token);
            if (!invite) {
                setInvitationError('Invito non valido o scaduto.');
            } else {
                setInvitation(invite);
                setEmail(invite.email); // Pre-fill email
            }
        } catch (err) {
            console.error('Validation error:', err);
            setInvitationError('Invito non valido o scaduto.');
        } finally {
            setLoading(false);
        }
    };

    const handleAuth = async (e: React.FormEvent) => {
        e.preventDefault();
        setAuthLoading(true);
        setAuthError(null);

        try {
            let user = null;
            if (authMode === 'signin') {
                const session = await api.auth.signIn(email, password);
                user = session.user;
            } else {
                const session = await api.auth.signUp(email, password);
                if (session?.user) {
                    user = session.user;
                    // Update full name if signed up
                    if (fullName) {
                        await api.settings.updateProfile(user.id, { full_name: fullName });
                    }
                } else {
                    // Confirmation email sent
                    setAuthError('Controlla la tua email per confermare l\'account, poi effettua il login.');
                    setAuthLoading(false);
                    return;
                }
            }

            if (user) {
                try {
                    // If logged in, accept invitation
                    await api.settings.acceptInvitation(token!, user.id, invitation.studio_id, invitation.role);
                    // Force reload/redirect to refresh context
                    window.location.href = '/dashboard';
                } catch (acceptErr: any) {
                    console.error('Acceptance error:', acceptErr);
                    setAuthError(`Errore durante l'accettazione: ${acceptErr.message || 'Sconosciuto'}`);
                    setAuthLoading(false);
                    return;
                }
            }

        } catch (err: any) {
            console.error('Auth error:', err);
            setAuthError('Credenziali non valide');
        } finally {
            // Only stop loading if we didn't redirect (redirect happens on success)
            // But here we might want to stop if we are just showing error
            if (authLoading) setAuthLoading(false);
        }
    };

    if (loading) {
        return <div className="min-h-screen bg-bg-primary flex items-center justify-center text-white">Validazione invito...</div>;
    }

    if (invitationError) {
        return (
            <div className="min-h-screen bg-bg-primary flex items-center justify-center p-4">
                <div className="bg-bg-secondary p-8 rounded-xl border border-red-500/30 max-w-md w-full text-center">
                    <AlertTriangle size={48} className="mx-auto text-red-500 mb-4" />
                    <h2 className="text-xl font-bold text-white mb-2">Invito Non Valido</h2>
                    <p className="text-text-muted mb-6">{invitationError}</p>
                    <button onClick={() => navigate('/')} className="text-accent hover:underline">Torna alla Dashboard</button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-bg-primary flex flex-col items-center justify-center p-4">
            <div className="bg-bg-secondary p-8 rounded-xl border border-border max-w-md w-full shadow-2xl">
                <div className="text-center mb-8">
                    <div className="inline-flex p-4 rounded-full bg-accent/10 text-accent mb-4">
                        <Shield size={32} />
                    </div>
                    <h1 className="text-2xl font-bold text-white mb-2">Accetta Invito</h1>
                    <p className="text-text-muted text-sm">
                        Sei stato invitato a unirti al team come <span className="text-white font-medium capitalize">{invitation.role}</span>.
                    </p>
                </div>

                <div className="flex bg-bg-tertiary p-1 rounded-lg mb-6">
                    <button
                        onClick={() => setAuthMode('signin')}
                        className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${authMode === 'signin' ? 'bg-bg-primary text-white shadow' : 'text-text-muted hover:text-white'}`}
                    >
                        Ho già un account
                    </button>
                    <button
                        onClick={() => setAuthMode('signup')}
                        className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${authMode === 'signup' ? 'bg-bg-primary text-white shadow' : 'text-text-muted hover:text-white'}`}
                    >
                        Crea account
                    </button>
                </div>

                <form onSubmit={handleAuth} className="space-y-4">
                    {authMode === 'signup' && (
                        <div>
                            <label className="block text-xs font-medium text-text-muted mb-1 uppercase">Nome Completo</label>
                            <input
                                type="text"
                                value={fullName}
                                onChange={e => setFullName(e.target.value)}
                                className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-accent focus:border-accent"
                                placeholder="Mario Rossi"
                                required
                            />
                        </div>
                    )}

                    <div>
                        <label className="block text-xs font-medium text-text-muted mb-1 uppercase">Email</label>
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
                            <input
                                type="email"
                                value={email}
                                onChange={e => setEmail(e.target.value)}
                                className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-accent focus:border-accent"
                                placeholder="tu@esempio.com"
                                required
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-medium text-text-muted mb-1 uppercase">Password</label>
                        <div className="relative">
                            <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
                            <input
                                type="password"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-accent focus:border-accent"
                                placeholder="••••••••"
                                required
                                minLength={6}
                            />
                        </div>
                    </div>

                    {authError && (
                        <div className="p-3 bg-red-500/10 border border-red-500/20 rounded text-red-500 text-sm">
                            {authError}
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={authLoading}
                        className="w-full py-3 bg-accent hover:bg-accent-hover text-white rounded-lg font-bold transition-all disabled:opacity-50 mt-4 flex items-center justify-center gap-2"
                    >
                        {authLoading ? 'Elaborazione...' : (authMode === 'signin' ? 'Accedi e Unisciti' : 'Registrati e Unisciti')}
                    </button>
                </form>
            </div>
        </div>
    );
};
