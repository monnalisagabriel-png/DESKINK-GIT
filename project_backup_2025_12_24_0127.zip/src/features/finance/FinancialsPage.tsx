import React, { useState, useEffect } from 'react';
import {
    DollarSign,
    TrendingUp,
    TrendingDown,
    Filter,
    Download
} from 'lucide-react';
import { api } from '../../services/api';
import type { Transaction, FinancialStats, ArtistContract } from '../../services/types';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { it } from 'date-fns/locale';
import clsx from 'clsx';
import { useAuth } from '../auth/AuthContext';
import { useLayoutStore } from '../../stores/layoutStore';

export const FinancialsPage: React.FC = () => {
    const { user } = useAuth();
    const { isPrivacyMode } = useLayoutStore();
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [stats, setStats] = useState<FinancialStats | null>(null);
    const [loading, setLoading] = useState(true);
    const [contract, setContract] = useState<ArtistContract | null>(null);

    // Default to current month
    const [dateRange] = useState({
        start: startOfMonth(new Date()),
        end: endOfMonth(new Date())
    });

    useEffect(() => {
        if (user) {
            loadData();
        }
    }, [dateRange, user]);

    const loadData = async () => {
        setLoading(true);
        try {
            if (!user) return;

            // Fetch base data
            const [allTxs, globalStats] = await Promise.all([
                api.financials.listTransactions(dateRange.start, dateRange.end),
                api.financials.getStats(dateRange.start)
            ]);

            if (user.role === 'ARTIST') {
                // 1. Fetch Contract for Commission Rate
                const artistContract = await api.artists.getContract(user.id);
                setContract(artistContract);
                const commissionRate = artistContract?.commission_rate || 50;

                // 2. Filter Transactions for Artist
                const artistTxs = allTxs.filter(tx => tx.artist_id === user.id);
                setTransactions(artistTxs);

                // 3. Calculate Artist Specific Stats
                // Income: Sum of (Transaction Amount * Commission%) for INCOME type
                const income = artistTxs
                    .filter(tx => tx.type === 'INCOME')
                    .reduce((acc, tx) => acc + (tx.amount * commissionRate / 100), 0);

                // Expenses: Direct expenses (type EXPENSE assigned to artist), assuming 100% responsibility?
                // Or maybe unrelated. Let's assume expenses assigned to artist are theirs.
                const expenses = artistTxs
                    .filter(tx => tx.type === 'EXPENSE')
                    .reduce((acc, tx) => acc + tx.amount, 0);

                setStats({
                    revenue_month: income,
                    expenses_month: expenses,
                    revenue_today: 0 // Not calculating daily for now to keep simple
                });

            } else {
                // Admin/Manager View - Show All
                setTransactions(allTxs);
                setStats(globalStats);
            }

        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (amount: number) => {
        if (isPrivacyMode) return '••••••';
        return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(amount);
    };

    if (!user) return null;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white">
                        {user.role === 'ARTIST' ? 'Le Tue Finanze' : 'Finanze Studio'}
                    </h1>
                    <p className="text-text-muted">
                        {user.role === 'ARTIST'
                            ? 'Monitora i tuoi guadagni e le commissioni.'
                            : 'Monitora entrate, uscite e commissioni.'}
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <button className="flex items-center gap-2 bg-bg-secondary border border-border hover:bg-white/5 text-text-primary px-4 py-2 rounded-lg font-medium transition-colors">
                        <Filter size={18} />
                        <span>Filtra</span>
                    </button>
                    <button className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-medium transition-colors">
                        <Download size={18} />
                        <span className="hidden md:inline">Esporta Report</span>
                    </button>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'I Tuoi Guadagni (Mese)' : 'Entrate Totali (Mese)'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">{stats ? formatCurrency(stats.revenue_month) : '-'}</h3>
                        <div className="p-2 bg-green-500/10 text-green-500 rounded-lg"><TrendingUp size={20} /></div>
                    </div>
                </div>
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'Spese Delegate' : 'Uscite (Mese)'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">{stats ? formatCurrency(stats.expenses_month) : '-'}</h3>
                        <div className="p-2 bg-red-500/10 text-red-500 rounded-lg"><TrendingDown size={20} /></div>
                    </div>
                </div>
                <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                    <p className="text-text-muted text-sm font-medium mb-1">
                        {user.role === 'ARTIST' ? 'Netto Stimato' : 'Utile Netto'}
                    </p>
                    <div className="flex items-end justify-between">
                        <h3 className="text-2xl font-bold text-white">
                            {stats ? formatCurrency(stats.revenue_month - stats.expenses_month) : '-'}
                        </h3>
                        <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg"><DollarSign size={20} /></div>
                    </div>
                </div>
            </div>

            {/* Chart Placeholder (Mock) */}
            <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                <h3 className="text-lg font-bold text-white mb-6">Andamento Entrate</h3>
                <div className="h-64 flex items-end justify-between gap-2 px-2">
                    {[40, 65, 30, 80, 55, 90, 45, 70, 60, 85, 50, 75].map((h, i) => (
                        <div key={i} className="w-full bg-bg-tertiary hover:bg-accent/50 transition-colors rounded-t-sm relative group" style={{ height: `${h}%` }}>
                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                {isPrivacyMode ? '•••' : `€${h * 10}`}
                            </div>
                        </div>
                    ))}
                </div>
                <div className="flex justify-between mt-4 text-xs text-text-muted px-2">
                    {['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'].map(m => (
                        <span key={m}>{m}</span>
                    ))}
                </div>
            </div>

            {/* Transactions Table */}
            <div className="bg-bg-secondary rounded-lg border border-border overflow-hidden">
                <div className="p-6 border-b border-border">
                    <h3 className="text-lg font-bold text-white">Transazioni Recenti</h3>
                </div>
                <table className="w-full text-left border-collapse">
                    <thead className="bg-bg-tertiary">
                        <tr className="text-sm text-text-muted font-medium border-b border-border">
                            <th className="px-6 py-3">Data</th>
                            <th className="px-6 py-3">Descrizione/Categoria</th>
                            <th className="px-6 py-3">Tipo</th>
                            <th className="px-6 py-3 text-right">
                                {user.role === 'ARTIST' ? 'Tua Quota' : 'Importo'}
                            </th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {loading ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Caricamento transazioni...</td></tr>
                        ) : transactions.length === 0 ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Nessuna transazione trovata.</td></tr>
                        ) : (
                            transactions.map(tx => {
                                const amount = user.role === 'ARTIST' && tx.type === 'INCOME'
                                    ? (tx.amount * (contract?.commission_rate || 50) / 100)
                                    : tx.amount;

                                return (
                                    <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                                        <td className="px-6 py-4 text-sm text-text-secondary">
                                            {format(new Date(tx.date), 'dd MMM yyyy', { locale: it })}
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-white">{tx.category}</div>
                                            {tx.description && <div className="text-xs text-text-muted">{tx.description}</div>}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={clsx(
                                                "text-xs px-2 py-1 rounded font-medium",
                                                tx.type === 'INCOME' ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                                            )}>
                                                {tx.type === 'INCOME' ? 'ENTRATA' : 'USCITA'}
                                            </span>
                                        </td>
                                        <td className={clsx(
                                            "px-6 py-4 text-right font-medium",
                                            tx.type === 'INCOME' ? "text-green-500" : "text-text-primary"
                                        )}>
                                            {tx.type === 'EXPENSE' ? '-' : '+'}{formatCurrency(amount)}
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
