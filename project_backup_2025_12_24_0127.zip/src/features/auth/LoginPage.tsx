import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';

const MOCK_CREDENTIALS = [
    { role: 'Admin', email: 'admin@inkflow.com' },
    { role: 'Manager', email: 'manager@inkflow.com' },
    { role: 'Artist', email: 'artist@inkflow.com' },
    { role: 'Student', email: 'student@inkflow.com' },
];

export const LoginPage: React.FC = () => {
    const { signIn } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    // Check if we are in Mock/Demo mode
    const isDemoMode = import.meta.env.VITE_USE_MOCK === 'true' || import.meta.env.VITE_USE_MOCK === true;

    const from = location.state?.from?.pathname || '/';

    const handleLogin = async (loginEmail: string, loginPassword?: string) => {
        setLoading(true);
        try {
            await signIn(loginEmail, loginPassword);
            navigate(from, { replace: true });
        } catch (error) {
            console.error('Login failed:', error);
            alert('Login failed. Please check your credentials.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-bg-primary p-4">
            <div className="w-full max-w-md p-8 bg-bg-secondary rounded-lg border border-border shadow-2xl">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-accent to-red-500 bg-clip-text text-transparent mb-2">
                        InkFlow
                    </h1>
                    <p className="text-text-muted">
                        {isDemoMode ? 'Demo Mode Active' : 'Sign in to your account'}
                    </p>
                    {!isDemoMode && (
                        <div className="mt-2 text-xs text-yellow-500 bg-yellow-500/10 p-2 rounded border border-yellow-500/20">
                            Running in Real Mode (Supabase). For Demo, run <code>npm run demo</code>.
                        </div>
                    )}
                </div>

                {/* Standard Login Form */}
                <form onSubmit={(e) => { e.preventDefault(); handleLogin(email, password); }} className="space-y-4 mb-8 pb-8 border-b border-border">
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-bg-tertiary border border-border rounded-lg px-3 py-2 text-white focus:ring-accent focus:border-accent"
                            placeholder="name@example.com"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-bg-tertiary border border-border rounded-lg px-3 py-2 text-white focus:ring-accent focus:border-accent"
                            placeholder="Enter your password"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-2 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors"
                    >
                        {loading ? 'Signing in...' : 'Sign In'}
                    </button>
                </form>

                <div className="space-y-4">
                    <p className="text-sm text-text-muted text-center mb-4">Or select a role (Demo Mode):</p>
                    {MOCK_CREDENTIALS.map((cred) => (
                        <button
                            key={cred.role}
                            onClick={() => handleLogin(cred.email)}
                            disabled={loading || !isDemoMode}
                            className={`w-full p-4 border border-border rounded-lg flex items-center justify-between group transition-all ${isDemoMode
                                    ? 'bg-bg-tertiary hover:bg-white/5 cursor-pointer'
                                    : 'bg-bg-primary opacity-50 cursor-not-allowed'
                                }`}
                            title={!isDemoMode ? "Available only in Demo Mode (npm run demo)" : "Quick Login"}
                        >
                            <span className="font-medium text-text-primary group-hover:text-accent transition-colors">
                                {cred.role}
                            </span>
                            <span className="text-xs text-text-muted">{cred.email}</span>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};
