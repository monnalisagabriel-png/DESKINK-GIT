import React from 'react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Calendar as CalIcon, Users } from 'lucide-react';
import type { CalendarView } from '../hooks/useCalendar';
import type { User } from '../../../services/types';
import clsx from 'clsx';

interface CalendarHeaderProps {
    currentDate: Date;
    view: CalendarView;
    onViewChange: (view: CalendarView) => void;
    onNext: () => void;
    onPrev: () => void;
    onToday: () => void;
    artists: User[];
    selectedArtistId: string | null;
    onArtistChange: (artistId: string | null) => void;
    onNewAppointment?: () => void;
}

export const CalendarHeader: React.FC<CalendarHeaderProps> = ({
    currentDate,
    view,
    onViewChange,
    onNext,
    onPrev,
    onToday,
    artists,
    selectedArtistId,
    onArtistChange,
    onNewAppointment
}) => {
    return (
        <div className="flex flex-col xl:flex-row items-center justify-between mb-6 gap-4">
            <div className="flex items-center gap-4 w-full md:w-auto justify-between">
                <h2 className="text-2xl font-bold text-white capitalize">
                    {format(currentDate, 'MMMM yyyy', { locale: it })}
                </h2>
                <div className="flex items-center bg-bg-secondary rounded-lg border border-border p-1">
                    <button onClick={onPrev} className="p-1 hover:text-accent transition-colors"><ChevronLeft /></button>
                    <button onClick={onToday} className="px-3 text-sm font-medium hover:text-accent transition-colors">Oggi</button>
                    <button onClick={onNext} className="p-1 hover:text-accent transition-colors"><ChevronRight /></button>
                </div>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto">
                {/* Artist Filter */}
                <div className="flex items-center bg-bg-secondary rounded-lg border border-border px-3 py-1.5 w-full md:w-auto">
                    <Users size={16} className="text-text-muted mr-2" />
                    <select
                        className="bg-transparent text-white text-sm outline-none w-full md:w-40"
                        value={selectedArtistId || 'all'}
                        onChange={(e) => onArtistChange(e.target.value === 'all' ? null : e.target.value)}
                    >
                        <option value="all" className="bg-bg-secondary text-white">Tutti gli Artisti</option>
                        {artists.map(artist => (
                            <option key={artist.id} value={artist.id} className="bg-bg-secondary text-white">
                                {artist.full_name}
                            </option>
                        ))}
                    </select>
                </div>

                {/* View Switch */}
                <div className="flex bg-bg-secondary rounded-lg border border-border p-1 w-full md:w-auto justify-center">
                    {(['year', 'month', 'week', 'day'] as CalendarView[]).map((v) => (
                        <button
                            key={v}
                            onClick={() => onViewChange(v)}
                            className={clsx(
                                "px-4 py-1.5 rounded-md text-sm font-medium capitalize transition-all flex-1 md:flex-none text-center",
                                view === v ? "bg-accent text-white shadow-sm" : "text-text-muted hover:text-text-primary"
                            )}
                        >
                            {v === 'year' && 'Anno'}
                            {v === 'month' && 'Mese'}
                            {v === 'week' && 'Sett.'}
                            {v === 'day' && 'Giorno'}
                        </button>
                    ))}
                </div>

                <button
                    onClick={onNewAppointment}
                    className="flex items-center justify-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg transition-colors font-medium whitespace-nowrap w-full md:w-auto"
                >
                    <CalIcon size={18} />
                    Nuovo Appuntamento
                </button>
            </div>
        </div>
    );
};
