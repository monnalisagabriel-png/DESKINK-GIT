import React, { useState, useEffect } from 'react';
import { Search, Plus, MoreHorizontal, Mail, Phone, MessageCircle, Megaphone, Download, Upload, FileSpreadsheet } from 'lucide-react';
import { api } from '../../services/api';
import type { Client } from '../../services/types';
import { useNavigate } from 'react-router-dom';

export const ClientsList: React.FC = () => {
    const [clients, setClients] = useState<Client[]>([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        loadClients();
    }, [search]);

    const loadClients = async () => {
        setLoading(true);
        try {
            const data = await api.clients.list(search);
            setClients(data);
        } finally {
            setLoading(false);
        }
    };

    const handleWhatsAppClick = (e: React.MouseEvent, phone: string) => {
        e.stopPropagation(); // Prevent row click navigation
        const cleanPhone = phone.replace(/\D/g, '');
        window.open(`https://wa.me/${cleanPhone}`, '_blank');
    };

    const handleToggleBroadcast = async (e: React.MouseEvent, client: Client) => {
        e.stopPropagation();
        try {
            await api.clients.update(client.id, {
                whatsapp_broadcast_opt_in: !client.whatsapp_broadcast_opt_in
            });
            // Reload to reflect changes
            loadClients();
        } catch (error) {
            console.error('Error toggling broadcast status:', error);
        }
    };

    const [isSheetConnected, setIsSheetConnected] = useState(false);

    // Mock generic "file input" ref for import
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const handleExportCSV = () => {
        // Create CSV content
        const headers = ['ID', 'Nome', 'Email', 'Telefono', 'Indirizzo', 'Città', 'Codice Fiscale'];
        const rows = clients.map(c => [
            c.id,
            c.full_name,
            c.email,
            c.phone,
            c.address || '',
            c.city || '',
            c.fiscal_code || ''
        ]);

        const csvContent = "data:text/csv;charset=utf-8,"
            + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "clienti_inkflow.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // Mock import process
            alert(`File "${file.name}" selezionato! In una versione reale, questo file verrebbe analizzato per creare nuovi clienti.`);
            // Reset input
            e.target.value = '';
        }
    };

    const handleGoogleSheetConnect = () => {
        if (isSheetConnected) {
            alert('Sincronizzazione con Google Sheets completata!');
        } else {
            const confirmed = window.confirm("Vuoi collegare il tuo account Google per sincronizzare i contatti con Google Sheets?");
            if (confirmed) {
                setIsSheetConnected(true);
                alert("Account Google collegato con successo! I contatti verranno sincronizzati automaticamente.");
            }
        }
    };

    return (
        <div className="h-full flex flex-col">
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".csv,.xlsx,.xls"
                className="hidden"
            />

            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
                <div>
                    <h1 className="text-2xl font-bold text-white">Clienti</h1>
                    <p className="text-text-muted">Gestisci il database e lo storico clienti.</p>
                </div>
                <div className="flex flex-col md:flex-row items-center gap-3 w-full md:w-auto">
                    {/* Action Buttons Group */}
                    <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
                        <button
                            onClick={handleGoogleSheetConnect}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium transition-colors border whitespace-nowrap ${isSheetConnected
                                ? 'bg-green-500/10 text-green-500 border-green-500/50 hover:bg-green-500/20'
                                : 'bg-bg-secondary text-text-secondary border-border hover:bg-white/5 hover:text-white'
                                }`}
                            title="Collega Google Sheets"
                        >
                            <FileSpreadsheet size={18} />
                            <span className="hidden lg:inline">{isSheetConnected ? 'Sync Sheets' : 'Collega Sheets'}</span>
                        </button>

                        <button
                            onClick={handleExportCSV}
                            className="flex items-center gap-2 bg-bg-secondary border border-border hover:bg-white/5 text-text-secondary hover:text-white px-3 py-2 rounded-lg font-medium transition-colors whitespace-nowrap"
                            title="Esporta CSV"
                        >
                            <Download size={18} />
                            <span className="hidden lg:inline">Esporta</span>
                        </button>

                        <button
                            onClick={handleImportClick}
                            className="flex items-center gap-2 bg-bg-secondary border border-border hover:bg-white/5 text-text-secondary hover:text-white px-3 py-2 rounded-lg font-medium transition-colors whitespace-nowrap"
                            title="Importa CSV"
                        >
                            <Upload size={18} />
                            <span className="hidden lg:inline">Importa</span>
                        </button>
                    </div>

                    <div className="relative flex-1 md:w-64 w-full">
                        <input
                            type="text"
                            placeholder="Cerca cliente..."
                            className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-2 text-white focus:ring-2 focus:ring-accent focus:border-transparent outline-none"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <Search className="absolute left-3 top-2.5 text-text-muted" size={18} />
                    </div>
                    <button
                        onClick={() => navigate('/clients/new')}
                        className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap w-full md:w-auto justify-center"
                    >
                        <Plus size={18} />
                        <span className="hidden md:inline">Nuovo Cliente</span>
                    </button>
                </div>
            </div>

            {/* Table */}
            <div className="bg-bg-secondary rounded-lg border border-border overflow-hidden flex-1">
                <table className="w-full text-left border-collapse">
                    <thead className="bg-bg-tertiary">
                        <tr className="text-sm text-text-muted font-medium border-b border-border">
                            <th className="px-6 py-3">Nome</th>
                            <th className="px-6 py-3">Contatti</th>
                            <th className="px-6 py-3">Ultima Visita</th>
                            <th className="px-6 py-3 text-right">Azioni</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {loading ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Caricamento...</td></tr>
                        ) : clients.length === 0 ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Nessun cliente trovato per "{search}"</td></tr>
                        ) : (
                            clients.map(client => (
                                <tr
                                    key={client.id}
                                    onClick={() => navigate(`/clients/${client.id}`)}
                                    className="hover:bg-white/5 cursor-pointer transition-colors group"
                                >
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-white">{client.full_name}</div>
                                        <div className="text-xs text-text-muted">ID: {client.id}</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col gap-1 text-sm text-text-secondary">
                                            <div className="flex items-center gap-2">
                                                <Mail size={14} /> {client.email}
                                            </div>
                                            <div
                                                className="flex items-center gap-2 hover:text-white cursor-pointer transition-colors"
                                                onClick={(e) => handleWhatsAppClick(e, client.phone)}
                                                title="Apri WhatsApp"
                                            >
                                                <Phone size={14} /> {client.phone}
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-text-secondary">
                                        -
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end items-center gap-2">
                                            <button
                                                onClick={(e) => handleToggleBroadcast(e, client)}
                                                className={`p-2 rounded-lg transition-colors ${client.whatsapp_broadcast_opt_in
                                                    ? 'text-green-500 hover:bg-green-500/10'
                                                    : 'text-text-muted hover:text-white hover:bg-bg-tertiary'
                                                    }`}
                                                title={client.whatsapp_broadcast_opt_in ? "Rimuovi da Broadcast" : "Aggiungi a Broadcast"}
                                            >
                                                <Megaphone size={18} />
                                            </button>
                                            <button
                                                onClick={(e) => handleWhatsAppClick(e, client.phone)}
                                                className="p-2 hover:bg-[#25D366]/20 text-[#25D366] rounded-lg transition-colors"
                                                title="Apri WhatsApp"
                                            >
                                                <MessageCircle size={18} />
                                            </button>
                                            <button className="p-2 hover:bg-bg-tertiary rounded-lg text-text-muted hover:text-white transition-colors">
                                                <MoreHorizontal size={18} />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
