
import React, { useState, useEffect } from 'react';
import { Search, FileSignature, CheckCircle, XCircle } from 'lucide-react';
import { api } from '../../../services/api';
import type { Client, ClientConsent } from '../../../services/types';

import { generateConsentPDF } from '../../../utils/pdfGenerator';

interface ClientsTabProps {
    onStartSignature: (client: Client) => void;
}

export const ClientsTab: React.FC<ClientsTabProps> = ({ onStartSignature }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [clients, setClients] = useState<Client[]>([]);
    const [loading, setLoading] = useState(false);
    const [downloading, setDownloading] = useState<string | null>(null);
    const [clientConsents, setClientConsents] = useState<Record<string, ClientConsent | null>>({});

    useEffect(() => {
        loadClients();
    }, [searchTerm]);

    const loadClients = async () => {
        setLoading(true);
        try {
            const data = await api.clients.list(searchTerm);
            setClients(data);
            // In a real app, we would optimize this to not N+1
            // For now, we only load status for the first few or on demand
            data.forEach(client => checkConsentStatus(client.id));
        } finally {
            setLoading(false);
        }
    };

    const checkConsentStatus = async (clientId: string) => {
        try {
            const consents = await api.consents.listClientConsents(clientId);
            // Assuming we care about the latest valid one
            const latest = consents.find(c => c.status === 'SIGNED');
            setClientConsents(prev => ({
                ...prev,
                [clientId]: latest || null
            }));
        } catch (error) {
            console.error(error);
        }
    };

    const handleDownloadPDF = async (client: Client, consent: ClientConsent) => {
        setDownloading(client.id);
        try {
            // Fetch template content again to ensure we have the text
            // In a real scenario, we might want to fetch the specific version linked to consent
            const template = await api.consents.getTemplate(client.studio_id);
            if (!template) throw new Error("Template not found");

            await generateConsentPDF(client, template, consent);
        } catch (err) {
            console.error(err);
            alert("Errore durante la generazione del PDF");
        } finally {
            setDownloading(null);
        }
    };

    return (
        <div className="space-y-6">
            <div className="relative">
                <input
                    type="text"
                    placeholder="Cerca cliente per nome..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-3 text-white outline-none focus:ring-2 focus:ring-accent"
                />
                <Search className="absolute left-3 top-3.5 text-text-muted" size={20} />
            </div>

            <div className="bg-bg-secondary border border-border rounded-lg overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-bg-tertiary text-text-muted uppercase text-xs font-semibold">
                        <tr>
                            <th className="p-4">Cliente</th>
                            <th className="p-4">Contatti</th>
                            <th className="p-4">Stato Consenso</th>
                            <th className="p-4 text-right">Azioni</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border/50">
                        {loading ? (
                            <tr>
                                <td colSpan={4} className="p-8 text-center text-text-muted">
                                    Caricamento...
                                </td>
                            </tr>
                        ) : clients.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="p-8 text-center text-text-muted">
                                    Nessun cliente trovato.
                                </td>
                            </tr>
                        ) : (
                            clients.map(client => {
                                const consent = clientConsents[client.id];
                                return (
                                    <tr key={client.id} className="hover:bg-white/5 transition-colors">
                                        <td className="p-4">
                                            <div className="font-medium text-white">{client.full_name}</div>
                                            <div className="text-xs text-text-muted">CF: {client.fiscal_code || '-'}</div>
                                        </td>
                                        <td className="p-4 text-sm text-text-muted">
                                            <div>{client.email}</div>
                                            <div>{client.phone}</div>
                                        </td>
                                        <td className="p-4">
                                            {consent ? (
                                                <div className="flex items-center gap-2 text-green-400 bg-green-400/10 px-3 py-1 rounded-full w-fit">
                                                    <CheckCircle size={14} />
                                                    <span className="text-xs font-medium">Firmato il {new Date(consent.signed_at).toLocaleDateString()}</span>
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-2 text-yellow-500 bg-yellow-500/10 px-3 py-1 rounded-full w-fit">
                                                    <XCircle size={14} />
                                                    <span className="text-xs font-medium">Non firmato</span>
                                                </div>
                                            )}
                                        </td>
                                        <td className="p-4 text-right">
                                            {consent ? (
                                                <button
                                                    className="text-sm text-accent hover:text-accent-hover font-medium underline px-3 disabled:opacity-50"
                                                    onClick={() => handleDownloadPDF(client, consent)}
                                                    disabled={downloading === client.id}
                                                >
                                                    {downloading === client.id ? 'Generazione...' : 'Scarica PDF'}
                                                </button>
                                            ) : (
                                                <button
                                                    onClick={() => onStartSignature(client)}
                                                    className="bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ml-auto"
                                                >
                                                    <FileSignature size={16} />
                                                    Avvia Firma
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
